
import base64

ENCODED_KEYS = [
    "QUJDMTIzLVhZWjc4OQ==",  # ABC123-XYZ789
    "VFJJQUwtNDU2REVG"       # TRIAL-456DEF
]

def validate_license(input_key):
    decoded_keys = [base64.b64decode(k).decode() for k in ENCODED_KEYS]
    return input_key.strip() in decoded_keys
