
# OSINT Apphunter Pro v1.0.0

**Features:**
- 🔐 License-locked usage (Base64 secured)
- 🕵️‍♂️ Scans across sherlock + maigret
- 📄 Generates JSON, TXT, CSV, PDF reports
- 🔄 Tor routing, stealth mode, encrypted output
- 💾 Self-contained `.exe` build with fancy installer
