
import requests
import os

GITHUB_API = "https://api.github.com"
REPO = "your-username/osint-apphunter"
TOKEN = "ghp_XXXXXXXXXXXXXXXXXXXXXXXX"
VERSION = "1.0.0"
ZIP_PATH = "osint_apphunter_pro.zip"

def create_release():
    url = f"{GITHUB_API}/repos/{REPO}/releases"
    headers = {"Authorization": f"token {TOKEN}"}
    payload = {
        "tag_name": VERSION,
        "name": f"v{VERSION}",
        "body": "Initial stable release of OSINT Apphunter Pro.",
        "draft": False,
        "prerelease": False
    }
    r = requests.post(url, headers=headers, json=payload)
    r.raise_for_status()
    return r.json()["upload_url"].split("{")[0]

def upload_asset(upload_url):
    headers = {
        "Authorization": f"token {TOKEN}",
        "Content-Type": "application/zip"
    }
    with open(ZIP_PATH, "rb") as f:
        r = requests.post(
            f"{upload_url}?name={os.path.basename(ZIP_PATH)}",
            headers=headers,
            data=f
        )
        r.raise_for_status()
        print("[+] Release uploaded successfully!")

if __name__ == "__main__":
    link = create_release()
    upload_asset(link)
